# 🏗️ QLVIN OS — Master Build Specification

> **Audience:** Claude Code / Gemini Code / Cursor / GitHub Copilot Workspace
> **Mode:** Autonomous full-stack implementation
> **Status:** Production MVP — ready to execute
> **Owner:** Sulaiman Al-Qahtani (سليمان القحطاني) + Abdulkader (عبدالقادر)

---

## 🎯 0. WHAT YOU'RE BUILDING (in one paragraph)

You are building **Qlvin OS** — a Luxury AI Hospitality Operating System for furnished apartments in Saudi Arabia. The system has 4 user interfaces (Founder, Host, Guest Card, In-Suite Tablet), connected to a Supabase backend, a Gemini intent-layer, a Raspberry Pi local controller via MQTT/Zigbee, and WhatsApp/iCal integrations. **The UI is already designed and approved — do not redesign it.** Your job is to wire it together, build the missing backend, implement the configurable feature system, and ship a working MVP that runs one real apartment.

---

## 🚨 1. NON-NEGOTIABLE RULES

Read these 12 rules. Violating any one = task failed.

1. **NEVER redesign approved HTML files.** Use them as-is:
   - `founder_v4_final.html` → Founder Dashboard
   - `host_v6.html` → Host Dashboard
   - `guest_smart_card_v3.html` → Guest Mobile Card
   - `guest_tablet_v1.html` → In-Suite Tablet
   
2. **NEVER let Gemini control devices directly.** Gemini returns JSON intent; Qlvin Core executes via MQTT.

3. **NEVER skip the Founder approval step.** No unit goes live without founder approval.

4. **NEVER expose API keys** in client-side code. All secrets in Supabase Edge Functions only.

5. **NEVER reuse guest tokens.** Each booking → fresh token → expires at checkout.

6. **ALWAYS log to `events` table.** Every meaningful action is an event.

7. **ALWAYS use the `unit.features` JSONB config.** Tablet UI is built from this config, not hardcoded.

8. **ALWAYS validate inputs** server-side. Never trust client.

9. **ALWAYS use Realtime channels** for live sync (Mobile Card ↔ Tablet ↔ Dashboards).

10. **ALWAYS prefer scripted Nawaf responses** (80%); Gemini only for unclear intents (20%).

11. **THE ASSISTANT IS NAMED "نواف" (Nawaf)** — not Fahad, not anyone else. Persona: Saudi, 27-30, calm, brief, 1-emoji max, ends with action/button.

12. **EVERY BUTTON MUST WORK.** No dead clicks. No "coming soon". If a feature is disabled in `unit.features`, hide the button entirely.

---

## 🏛️ 2. ARCHITECTURE OVERVIEW

```
┌─────────────────────────────────────────────────────────────┐
│  CLIENTS (HTML — DO NOT REDESIGN)                            │
│  ┌──────────┬──────────┬──────────┬──────────────────────┐  │
│  │ Founder  │  Host    │ Guest    │ In-Suite Tablet      │  │
│  │ v4_final │ v6       │ Card v3  │ tablet_v1            │  │
│  └──────────┴──────────┴──────────┴──────────────────────┘  │
└──────────────────────────┬──────────────────────────────────┘
                           ↓ (HTTPS + Realtime WS)
┌─────────────────────────────────────────────────────────────┐
│  SUPABASE BACKEND                                            │
│  ├─ PostgreSQL (16 tables)                                   │
│  ├─ Auth (Founder + Host roles, Guest = token-based)         │
│  ├─ Realtime (live sync across UIs)                          │
│  ├─ Storage (apartment photos, guides)                       │
│  └─ Edge Functions (8 functions, see §6)                     │
└──────────────────────────┬──────────────────────────────────┘
                           ↓
        ┌──────────────────┴──────────────────┐
        ↓                                     ↓
┌────────────────┐                  ┌────────────────────┐
│  Gemini 1.5    │                  │  MQTT Broker       │
│  Flash         │                  │  (HiveMQ Cloud or  │
│  (intent only) │                  │   self-hosted)     │
└────────────────┘                  └────────┬───────────┘
                                             ↓
                                    ┌────────────────────┐
                                    │  Raspberry Pi      │
                                    │  + Zigbee2MQTT     │
                                    │  + Sonoff Dongle   │
                                    └────────┬───────────┘
                                             ↓
                                    Devices (AC/Light/LED/Sensors)
```

---

## 📦 3. REPO STRUCTURE (build exactly this)

```
qlvin-os/
├── README.md
├── CLAUDE.md                        # ← this file
├── .env.example
├── .gitignore
├── package.json
├── pnpm-workspace.yaml
│
├── apps/
│   ├── founder/                     # Static site → Netlify
│   │   ├── index.html               # = founder_v4_final.html
│   │   ├── src/
│   │   │   ├── supabase-client.js
│   │   │   ├── auth.js
│   │   │   ├── hosts-manager.js     # CRUD + approval
│   │   │   ├── units-approval.js    # approval workflow
│   │   │   ├── live-feed.js         # realtime events
│   │   │   └── feature-defaults.js  # platform-wide defaults
│   │   └── netlify.toml
│   │
│   ├── host/                        # Static site → Netlify
│   │   ├── index.html               # = host_v6.html
│   │   ├── src/
│   │   │   ├── supabase-client.js
│   │   │   ├── auth.js
│   │   │   ├── units-manager.js     # add/edit/delete units
│   │   │   ├── tablet-builder.js    # ⭐ Feature Builder UI
│   │   │   ├── bookings-view.js
│   │   │   ├── guest-card-sender.js
│   │   │   └── activity-log.js
│   │   └── netlify.toml
│   │
│   ├── guest-card/                  # Static site → Netlify (public)
│   │   ├── index.html               # = guest_smart_card_v3.html
│   │   ├── src/
│   │   │   ├── token-handler.js     # validates token from URL
│   │   │   ├── realtime-sync.js     # syncs with tablet
│   │   │   ├── nawaf-client.js
│   │   │   └── feature-renderer.js  # renders by unit.features
│   │   └── netlify.toml
│   │
│   └── tablet/                      # Static site → Netlify
│       ├── index.html               # = guest_tablet_v1.html
│       ├── src/
│       │   ├── token-handler.js
│       │   ├── feature-renderer.js  # ⭐ reads unit.features, builds UI
│       │   ├── nawaf-engine.js      # scripted responses + Gemini fallback
│       │   ├── behavior-tracker.js  # Netflix confusion, etc.
│       │   ├── mqtt-bridge.js       # sends commands via Edge Functions
│       │   └── realtime-sync.js
│       └── netlify.toml
│
├── packages/                        # Shared code
│   ├── qlvn-config/                 # ⭐ Feature definitions
│   │   ├── feature-registry.json   # ALL available features
│   │   ├── default-config.json     # default config for new units
│   │   ├── validator.js
│   │   └── README.md
│   │
│   ├── qlvn-ui/                     # Shared UI helpers
│   │   ├── css-variables.css        # the Mood system
│   │   ├── components/
│   │   │   ├── time-ring.js
│   │   │   ├── ios-slider.js
│   │   │   ├── nawaf-card.js
│   │   │   └── liquid-notif.js
│   │   └── README.md
│   │
│   ├── qlvn-events/                 # Event bus
│   │   ├── index.js
│   │   └── event-types.js
│   │
│   └── qlvn-types/                  # Shared TypeScript types
│       └── index.d.ts
│
├── supabase/
│   ├── config.toml
│   ├── seed.sql
│   ├── migrations/
│   │   ├── 20260101_001_initial_schema.sql
│   │   ├── 20260101_002_rls_policies.sql
│   │   ├── 20260101_003_realtime.sql
│   │   ├── 20260101_004_feature_defaults.sql
│   │   └── 20260101_005_seed_demo_unit.sql
│   │
│   └── functions/
│       ├── _shared/
│       │   ├── cors.ts
│       │   ├── auth.ts
│       │   └── supabase.ts
│       │
│       ├── gemini-intent/index.ts       # Nawaf brain (fallback)
│       ├── ical-sync/index.ts           # cron every 15min
│       ├── whatsapp-send/index.ts       # Twilio wrapper
│       ├── guest-token-create/index.ts  # creates token on booking
│       ├── guest-token-validate/index.ts # public endpoint
│       ├── extension-request/index.ts
│       ├── automation-trigger/index.ts
│       └── mqtt-publish/index.ts        # cloud → Pi command
│
├── pi/                              # Raspberry Pi Controller
│   ├── README.md
│   ├── setup.sh                     # one-line install
│   ├── requirements.txt
│   ├── main.py
│   ├── config.example.yaml
│   ├── qlvin.service                # systemd
│   │
│   ├── services/
│   │   ├── __init__.py
│   │   ├── mqtt_service.py
│   │   ├── supabase_service.py
│   │   ├── presence_service.py
│   │   ├── automation_service.py
│   │   └── heartbeat_service.py
│   │
│   └── devices/
│       ├── __init__.py
│       ├── base_device.py
│       ├── ac_controller.py         # IR via broadlink
│       ├── light_controller.py      # Zigbee
│       ├── led_strip_controller.py
│       ├── door_sensor.py
│       └── presence_sensor.py
│
├── docs/
│   ├── ARCHITECTURE.md
│   ├── DEPLOYMENT.md
│   ├── FEATURES.md                  # the feature catalog
│   ├── SCENARIOS.md                 # the 5 MVP scenarios
│   ├── API.md
│   ├── PI_SETUP.md
│   └── CONTRIBUTING.md
│
└── .github/
    └── workflows/
        ├── deploy-founder.yml
        ├── deploy-host.yml
        ├── deploy-guest-card.yml
        ├── deploy-tablet.yml
        ├── deploy-functions.yml
        └── test.yml
```

---

## 🗄️ 4. DATABASE SCHEMA (Supabase PostgreSQL)

### File: `supabase/migrations/20260101_001_initial_schema.sql`

```sql
-- ============================================================
-- QLVIN OS — Initial Schema
-- ============================================================

-- ====================
-- 1. USERS
-- ====================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    auth_id UUID UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('founder', 'host', 'guest')),
    phone TEXT,
    email TEXT,
    avatar_url TEXT,
    
    -- For hosts
    commission_rate NUMERIC DEFAULT 15.0,  -- platform fee %
    bank_iban TEXT,
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ====================
-- 2. PROPERTIES (a host can have multiple properties)
-- ====================
CREATE TABLE properties (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    location TEXT,
    type TEXT CHECK (type IN ('apartment', 'chalet', 'resort', 'pod', 'villa')),
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'archived')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ====================
-- 3. UNITS (individual rentable units) — THE CORE TABLE
-- ====================
CREATE TABLE units (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    property_id UUID REFERENCES properties(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    short_name TEXT,
    qlvn_code TEXT UNIQUE,  -- e.g. "QLVN-1042"
    location TEXT,
    
    -- ⭐ Approval workflow
    approval_status TEXT DEFAULT 'pending_approval' CHECK (approval_status IN (
        'pending_approval',
        'approved',
        'rejected',
        'suspended'
    )),
    approval_requested_at TIMESTAMPTZ DEFAULT NOW(),
    approved_at TIMESTAMPTZ,
    approved_by UUID REFERENCES users(id),
    rejection_reason TEXT,
    suspended_reason TEXT,
    
    -- Operational status (only meaningful if approval_status = 'approved')
    operational_status TEXT DEFAULT 'available' CHECK (operational_status IN (
        'available',
        'occupied',
        'cleaning',
        'maintenance'
    )),
    
    -- ⭐ FEATURES CONFIG (the Lego system)
    features JSONB NOT NULL DEFAULT '{}',
    layout TEXT DEFAULT 'classic' CHECK (layout IN ('classic', 'immersive', 'wallet')),
    
    -- WiFi
    wifi_name TEXT,
    wifi_password TEXT,
    
    -- Climate
    current_temp NUMERIC,
    target_temp NUMERIC DEFAULT 22,
    
    -- Pi/IoT
    pi_id TEXT,
    pi_status TEXT DEFAULT 'offline' CHECK (pi_status IN ('online', 'offline')),
    pi_last_seen TIMESTAMPTZ,
    
    -- Pricing
    base_price_per_night NUMERIC,
    extension_price_per_hour NUMERIC DEFAULT 50,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_units_property ON units(property_id);
CREATE INDEX idx_units_approval ON units(approval_status);

-- ====================
-- 4. PLATFORM_FEATURE_DEFAULTS (founder-controlled)
-- ====================
CREATE TABLE platform_feature_defaults (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    feature_key TEXT UNIQUE NOT NULL,  -- e.g. "cinema_mode"
    enabled_by_default BOOLEAN DEFAULT true,
    host_can_disable BOOLEAN DEFAULT true,
    host_can_enable BOOLEAN DEFAULT true,
    config_schema JSONB,
    default_config JSONB,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ====================
-- 5. BOOKINGS (from iCal sync or manual)
-- ====================
CREATE TABLE bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
    external_booking_id TEXT,
    source TEXT CHECK (source IN ('airbnb', 'gathern', 'booking', 'direct', 'manual')),
    
    guest_name TEXT NOT NULL,
    guest_phone TEXT,
    guest_email TEXT,
    
    checkin_at TIMESTAMPTZ NOT NULL,
    checkout_at TIMESTAMPTZ NOT NULL,
    nights INT,
    total_price NUMERIC,
    
    status TEXT DEFAULT 'confirmed' CHECK (status IN (
        'pending', 'confirmed', 'active', 'completed', 'cancelled'
    )),
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(external_booking_id, source)
);

CREATE INDEX idx_bookings_unit ON bookings(unit_id);
CREATE INDEX idx_bookings_checkout ON bookings(checkout_at);

-- ====================
-- 6. GUEST_SESSIONS (active stays + tokens)
-- ====================
CREATE TABLE guest_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
    
    guest_name TEXT NOT NULL,
    guest_phone TEXT,
    
    -- Access
    access_code TEXT,
    code_changed_at TIMESTAMPTZ,
    
    -- ⭐ Token (for Smart Guest Card link)
    guest_token TEXT UNIQUE NOT NULL DEFAULT encode(gen_random_bytes(32), 'hex'),
    token_expires_at TIMESTAMPTZ NOT NULL,
    
    -- Status
    status TEXT DEFAULT 'pending' CHECK (status IN (
        'pending', 'active', 'completed', 'cancelled'
    )),
    checked_in_at TIMESTAMPTZ,
    checked_out_at TIMESTAMPTZ,
    early_checkout_reason TEXT,  -- if guest pressed Exit early
    
    -- Preferences
    preferences JSONB DEFAULT '{}',
    favorite_team TEXT,
    
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_guest_token_active ON guest_sessions(guest_token)
    WHERE status = 'active';
CREATE INDEX idx_guest_sessions_unit ON guest_sessions(unit_id);

-- ====================
-- 7. DEVICES
-- ====================
CREATE TABLE devices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN (
        'ac', 'light', 'led_strip', 'door', 'presence',
        'plug', 'switch', 'leak', 'temp', 'tv', 'lock'
    )),
    protocol TEXT CHECK (protocol IN ('zigbee', 'mqtt', 'wifi', 'ir', 'gpio')),
    mqtt_topic TEXT,
    state JSONB DEFAULT '{}',
    status TEXT DEFAULT 'offline' CHECK (status IN ('online', 'offline')),
    last_seen TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_devices_unit ON devices(unit_id);

-- ====================
-- 8. EVENTS (everything is logged)
-- ====================
CREATE TABLE events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id UUID REFERENCES units(id) ON DELETE SET NULL,
    guest_session_id UUID REFERENCES guest_sessions(id) ON DELETE SET NULL,
    host_id UUID REFERENCES users(id) ON DELETE SET NULL,
    
    type TEXT NOT NULL,
    payload JSONB DEFAULT '{}',
    severity TEXT DEFAULT 'info' CHECK (severity IN ('info', 'warning', 'critical')),
    
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_events_unit_time ON events(unit_id, created_at DESC);
CREATE INDEX idx_events_type ON events(type);

-- ====================
-- 9. MESSAGES (Guest ↔ Nawaf)
-- ====================
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    guest_session_id UUID REFERENCES guest_sessions(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('guest', 'nawaf', 'system')),
    content TEXT NOT NULL,
    intent TEXT,
    used_gemini BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ====================
-- 10. AUTOMATION_RULES
-- ====================
CREATE TABLE automation_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id UUID REFERENCES units(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    trigger_type TEXT,
    conditions JSONB,
    actions JSONB,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ====================
-- 11. ORDERS (coffee, popcorn, food)
-- ====================
CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    guest_session_id UUID NOT NULL REFERENCES guest_sessions(id) ON DELETE CASCADE,
    unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
    item_name TEXT NOT NULL,
    item_type TEXT,
    quantity INT DEFAULT 1,
    price NUMERIC,
    status TEXT DEFAULT 'pending' CHECK (status IN (
        'pending', 'preparing', 'delivered', 'cancelled'
    )),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ====================
-- 12. EXTENSIONS
-- ====================
CREATE TABLE extensions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    guest_session_id UUID NOT NULL REFERENCES guest_sessions(id) ON DELETE CASCADE,
    duration_hours INT NOT NULL,
    price NUMERIC NOT NULL,
    status TEXT DEFAULT 'requested' CHECK (status IN (
        'requested', 'approved', 'rejected', 'paid'
    )),
    requested_at TIMESTAMPTZ DEFAULT NOW(),
    approved_at TIMESTAMPTZ,
    new_checkout_at TIMESTAMPTZ
);

-- ====================
-- 13. ICAL_FEEDS
-- ====================
CREATE TABLE ical_feeds (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
    source TEXT CHECK (source IN ('airbnb', 'gathern', 'booking', 'other')),
    url TEXT NOT NULL,
    last_synced_at TIMESTAMPTZ,
    sync_status TEXT DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ====================
-- 14. WHATSAPP_CONFIGS
-- ====================
CREATE TABLE whatsapp_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    host_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider TEXT DEFAULT 'twilio' CHECK (provider IN ('twilio', 'meta_cloud', 'mock')),
    from_number TEXT,
    api_credentials JSONB,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ====================
-- 15. APPROVAL_REQUESTS (audit log for approvals)
-- ====================
CREATE TABLE approval_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id UUID NOT NULL REFERENCES units(id) ON DELETE CASCADE,
    host_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    action TEXT NOT NULL CHECK (action IN ('approve', 'reject', 'suspend', 'reactivate')),
    reason TEXT,
    actor_id UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ====================
-- 16. NOTIFICATIONS (in-app + push)
-- ====================
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT,
    payload JSONB,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_notifications_recipient ON notifications(recipient_id, created_at DESC);

-- ============================================================
-- TRIGGERS
-- ============================================================

-- When a booking is created → auto-create guest_session + token
CREATE OR REPLACE FUNCTION create_guest_session_from_booking()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO guest_sessions (
        booking_id, unit_id, guest_name, guest_phone,
        token_expires_at, status
    )
    VALUES (
        NEW.id, NEW.unit_id, NEW.guest_name, NEW.guest_phone,
        NEW.checkout_at + INTERVAL '2 hours',
        'pending'
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_booking_creates_session
    AFTER INSERT ON bookings
    FOR EACH ROW
    EXECUTE FUNCTION create_guest_session_from_booking();

-- When unit is approved → set approved_at and notify host
CREATE OR REPLACE FUNCTION on_unit_approval_change()
RETURNS TRIGGER AS $$
DECLARE
    host_user_id UUID;
BEGIN
    SELECT p.owner_id INTO host_user_id
    FROM properties p WHERE p.id = NEW.property_id;
    
    IF NEW.approval_status = 'approved' AND OLD.approval_status != 'approved' THEN
        NEW.approved_at := NOW();
        INSERT INTO notifications (recipient_id, type, title, body)
        VALUES (host_user_id, 'unit_approved',
                'تمت الموافقة على وحدتك',
                'وحدة ' || NEW.name || ' أصبحت جاهزة لاستقبال الضيوف');
    ELSIF NEW.approval_status = 'rejected' AND OLD.approval_status != 'rejected' THEN
        INSERT INTO notifications (recipient_id, type, title, body, payload)
        VALUES (host_user_id, 'unit_rejected',
                'تم رفض الوحدة',
                NEW.rejection_reason,
                jsonb_build_object('unit_id', NEW.id));
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_unit_approval
    BEFORE UPDATE OF approval_status ON units
    FOR EACH ROW
    EXECUTE FUNCTION on_unit_approval_change();
```

### File: `supabase/migrations/20260101_002_rls_policies.sql`

```sql
-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE units ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE guest_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE devices ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE extensions ENABLE ROW LEVEL SECURITY;

-- Helper function
CREATE OR REPLACE FUNCTION user_role() RETURNS TEXT AS $$
    SELECT role FROM users WHERE auth_id = auth.uid();
$$ LANGUAGE SQL STABLE;

CREATE OR REPLACE FUNCTION user_id() RETURNS UUID AS $$
    SELECT id FROM users WHERE auth_id = auth.uid();
$$ LANGUAGE SQL STABLE;

-- ⭐ Founders see EVERYTHING
CREATE POLICY "founders_all" ON units
    FOR ALL USING (user_role() = 'founder');
CREATE POLICY "founders_all_properties" ON properties
    FOR ALL USING (user_role() = 'founder');
CREATE POLICY "founders_all_bookings" ON bookings
    FOR ALL USING (user_role() = 'founder');
CREATE POLICY "founders_all_events" ON events
    FOR ALL USING (user_role() = 'founder');
CREATE POLICY "founders_all_users" ON users
    FOR ALL USING (user_role() = 'founder');

-- ⭐ Hosts see only their own
CREATE POLICY "hosts_own_properties" ON properties
    FOR ALL USING (user_role() = 'host' AND owner_id = user_id());

CREATE POLICY "hosts_own_units" ON units
    FOR ALL USING (
        user_role() = 'host'
        AND property_id IN (SELECT id FROM properties WHERE owner_id = user_id())
    );

CREATE POLICY "hosts_own_bookings" ON bookings
    FOR SELECT USING (
        user_role() = 'host'
        AND unit_id IN (
            SELECT u.id FROM units u
            JOIN properties p ON u.property_id = p.id
            WHERE p.owner_id = user_id()
        )
    );

-- ⭐ Guests: NO direct DB access (only via Edge Functions with token)
-- (no policies for guest role; all guest access goes through token-validated endpoints)
```

### File: `supabase/migrations/20260101_003_realtime.sql`

```sql
-- Enable Realtime for live sync
ALTER PUBLICATION supabase_realtime ADD TABLE units;
ALTER PUBLICATION supabase_realtime ADD TABLE guest_sessions;
ALTER PUBLICATION supabase_realtime ADD TABLE events;
ALTER PUBLICATION supabase_realtime ADD TABLE orders;
ALTER PUBLICATION supabase_realtime ADD TABLE devices;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE bookings;
```

---

## ⚙️ 5. FEATURE REGISTRY (THE LEGO SYSTEM)

### File: `packages/qlvn-config/feature-registry.json`

This is the **catalog of every feature** the tablet can have. The Builder UI reads from this; the tablet renders from `unit.features`.

```json
{
  "version": "1.0",
  "categories": [
    {
      "id": "core",
      "label_ar": "أساسية",
      "label_en": "Core"
    },
    {
      "id": "modes",
      "label_ar": "الأوضاع",
      "label_en": "Modes"
    },
    {
      "id": "controls",
      "label_ar": "التحكم",
      "label_en": "Controls"
    },
    {
      "id": "actions",
      "label_ar": "الإجراءات",
      "label_en": "Actions"
    },
    {
      "id": "ordering",
      "label_ar": "الطلبات",
      "label_en": "Ordering"
    },
    {
      "id": "ai",
      "label_ar": "الذكاء",
      "label_en": "AI"
    },
    {
      "id": "info",
      "label_ar": "المعلومات",
      "label_en": "Info"
    }
  ],
  "features": [
    {
      "key": "time_ring",
      "category": "core",
      "label_ar": "عداد الوقت",
      "label_en": "Time Ring",
      "description_ar": "عداد دائري للوقت المتبقي",
      "icon": "⏱️",
      "default_enabled": true,
      "essential": true,
      "config_schema": {
        "size": { "type": "select", "options": ["small", "medium", "large"], "default": "large" },
        "show_checkout": { "type": "boolean", "default": true }
      }
    },
    {
      "key": "environment_display",
      "category": "core",
      "label_ar": "عرض البيئة",
      "label_en": "Environment Display",
      "icon": "🌡️",
      "default_enabled": true,
      "config_schema": {
        "show_climate": { "type": "boolean", "default": true },
        "show_outside": { "type": "boolean", "default": true },
        "show_humidity": { "type": "boolean", "default": true }
      }
    },
    {
      "key": "cinema_mode",
      "category": "modes",
      "label_ar": "وضع السينما",
      "label_en": "Cinema Mode",
      "icon": "🎬",
      "default_enabled": true,
      "config_schema": {
        "auto_dim_lights": { "type": "boolean", "default": true },
        "target_light_level": { "type": "number", "min": 0, "max": 100, "default": 20 }
      }
    },
    {
      "key": "match_mode",
      "category": "modes",
      "label_ar": "وضع المباراة",
      "label_en": "Match Mode",
      "icon": "⚽",
      "default_enabled": true,
      "config_schema": {
        "teams": {
          "type": "multiselect",
          "options": ["hilal", "nassr", "ittihad", "ahli", "qadisiya"],
          "default": ["hilal", "nassr", "ittihad", "ahli"]
        },
        "auto_show_only_on_match_days": { "type": "boolean", "default": true }
      }
    },
    {
      "key": "coffee_mode",
      "category": "modes",
      "label_ar": "وضع القهوة",
      "label_en": "Coffee Mode",
      "icon": "☕",
      "default_enabled": false
    },
    {
      "key": "relax_mode",
      "category": "modes",
      "label_ar": "وضع الاسترخاء",
      "label_en": "Relax Mode",
      "icon": "🌙",
      "default_enabled": true
    },
    {
      "key": "light_slider",
      "category": "controls",
      "label_ar": "تحكم الإضاءة",
      "label_en": "Light Slider",
      "icon": "💡",
      "default_enabled": true,
      "config_schema": {
        "min": { "type": "number", "default": 0 },
        "max": { "type": "number", "default": 100 }
      }
    },
    {
      "key": "sound_slider",
      "category": "controls",
      "label_ar": "تحكم الصوت",
      "label_en": "Sound Slider",
      "icon": "🔊",
      "default_enabled": true,
      "config_schema": {
        "min": { "type": "number", "default": 0 },
        "max": { "type": "number", "default": 100 }
      }
    },
    {
      "key": "rgb_slider",
      "category": "controls",
      "label_ar": "إضاءة RGB",
      "label_en": "RGB Light",
      "icon": "🌈",
      "default_enabled": false,
      "config_schema": {
        "colors": {
          "type": "multiselect",
          "options": ["red", "orange", "yellow", "green", "cyan", "blue", "purple"],
          "default": ["red", "orange", "yellow", "green", "cyan", "blue", "purple"]
        }
      }
    },
    {
      "key": "ac_control",
      "category": "controls",
      "label_ar": "تحكم المكيف",
      "label_en": "AC Control",
      "icon": "❄️",
      "default_enabled": true,
      "config_schema": {
        "min_temp": { "type": "number", "default": 18 },
        "max_temp": { "type": "number", "default": 28 }
      }
    },
    {
      "key": "extend_button",
      "category": "actions",
      "label_ar": "زر تمديد الإقامة",
      "label_en": "Extend Stay",
      "icon": "⏳",
      "default_enabled": true,
      "config_schema": {
        "options": {
          "type": "array_of_objects",
          "default": [
            { "hours": 1, "price": 50 },
            { "hours": 3, "price": 120 },
            { "hours": 6, "price": 200 },
            { "hours": 24, "price": 350 },
            { "hours": 48, "price": 650 },
            { "hours": 72, "price": 900 }
          ]
        }
      }
    },
    {
      "key": "exit_button",
      "category": "actions",
      "label_ar": "زر المغادرة المبكرة",
      "label_en": "Early Exit",
      "icon": "🚪",
      "default_enabled": true,
      "config_schema": {
        "require_confirmation": { "type": "boolean", "default": true },
        "auto_lock_door": { "type": "boolean", "default": true }
      }
    },
    {
      "key": "order_coffee",
      "category": "ordering",
      "label_ar": "طلب القهوة",
      "label_en": "Order Coffee",
      "icon": "☕",
      "default_enabled": false,
      "config_schema": {
        "menu": {
          "type": "array_of_objects",
          "default": [
            { "name": "قهوة عربية", "price": 10 },
            { "name": "اسبريسو", "price": 15 },
            { "name": "كابتشينو", "price": 18 }
          ]
        }
      }
    },
    {
      "key": "order_popcorn",
      "category": "ordering",
      "label_ar": "طلب فشار",
      "label_en": "Order Popcorn",
      "icon": "🍿",
      "default_enabled": false,
      "config_schema": {
        "price": { "type": "number", "default": 10 }
      }
    },
    {
      "key": "nawaf_assistant",
      "category": "ai",
      "label_ar": "المساعد نواف",
      "label_en": "Nawaf Assistant",
      "icon": "🤖",
      "default_enabled": true,
      "config_schema": {
        "use_gemini": { "type": "boolean", "default": true },
        "personality": { "type": "select", "options": ["calm", "warm"], "default": "calm" }
      }
    },
    {
      "key": "netflix_confusion_detection",
      "category": "ai",
      "label_ar": "اكتشاف الحيرة",
      "label_en": "Netflix Confusion",
      "icon": "👀",
      "default_enabled": true,
      "config_schema": {
        "trigger_after_minutes": { "type": "number", "default": 5 }
      }
    },
    {
      "key": "wifi_qr",
      "category": "info",
      "label_ar": "QR للواي فاي",
      "label_en": "WiFi QR",
      "icon": "📶",
      "default_enabled": true,
      "essential": true
    },
    {
      "key": "door_code",
      "category": "info",
      "label_ar": "رمز الباب",
      "label_en": "Door Code",
      "icon": "🔐",
      "default_enabled": true,
      "essential": true
    },
    {
      "key": "support_button",
      "category": "info",
      "label_ar": "زر الدعم",
      "label_en": "Support",
      "icon": "💬",
      "default_enabled": true,
      "essential": true
    }
  ]
}
```

### File: `packages/qlvn-config/default-config.json`

```json
{
  "layout": "classic",
  "features": {
    "time_ring": { "enabled": true, "config": { "size": "large", "show_checkout": true } },
    "environment_display": { "enabled": true, "config": { "show_climate": true, "show_outside": true, "show_humidity": true } },
    "cinema_mode": { "enabled": true, "config": { "auto_dim_lights": true, "target_light_level": 20 } },
    "match_mode": { "enabled": true, "config": { "teams": ["hilal", "nassr", "ittihad", "ahli"], "auto_show_only_on_match_days": true } },
    "coffee_mode": { "enabled": false },
    "relax_mode": { "enabled": true },
    "light_slider": { "enabled": true, "config": { "min": 0, "max": 100 } },
    "sound_slider": { "enabled": true, "config": { "min": 0, "max": 100 } },
    "rgb_slider": { "enabled": false },
    "ac_control": { "enabled": true, "config": { "min_temp": 18, "max_temp": 28 } },
    "extend_button": { "enabled": true },
    "exit_button": { "enabled": true, "config": { "require_confirmation": true, "auto_lock_door": true } },
    "order_coffee": { "enabled": false },
    "order_popcorn": { "enabled": false },
    "nawaf_assistant": { "enabled": true, "config": { "use_gemini": true, "personality": "calm" } },
    "netflix_confusion_detection": { "enabled": true, "config": { "trigger_after_minutes": 5 } },
    "wifi_qr": { "enabled": true },
    "door_code": { "enabled": true },
    "support_button": { "enabled": true }
  }
}
```

---

## 🔌 6. EDGE FUNCTIONS (8 functions)

For each function, write a Deno TypeScript file. Each must:
- Validate input
- Use `_shared/auth.ts` to verify caller
- Log to `events` table
- Return proper HTTP status codes
- Handle errors gracefully

### Function list (build each in order):

1. **`gemini-intent`** — Nawaf brain. Receives `{message, guest_session_id, unit_context}`. Returns JSON with `intent`, `reply_ar`, `actions`, `suggestions`. Rate-limited: 30/guest/hour. Validates schema before returning.

2. **`ical-sync`** — Cron job, runs every 15 min. For each unit with `ical_feeds`, fetch the .ics URL, parse new bookings, INSERT into `bookings`. Skip if `unit.approval_status != 'approved'`.

3. **`whatsapp-send`** — Wrapper for Twilio. Sends templated messages. Templates: `guest_card_link`, `checkout_reminder`, `extension_offer`. Falls back to mock if no credentials.

4. **`guest-token-create`** — Called by trigger after booking insert. Generates token, sets `token_expires_at = checkout_at + 2h`, calls `whatsapp-send` with guest card link.

5. **`guest-token-validate`** — Public endpoint. Receives `{token}`. Returns guest session data if: token exists + status='active' OR 'pending' + not expired. Returns 401 otherwise.

6. **`extension-request`** — Receives `{guest_session_id, hours, price}`. Creates `extensions` row. Notifies host. If host approves, extends `guest_sessions.token_expires_at`.

7. **`automation-trigger`** — Receives an event (presence/checkout/etc), evaluates `automation_rules`, executes matching actions.

8. **`mqtt-publish`** — Receives `{unit_id, device_id, command}`. Auth check. Publishes to MQTT broker via WebSocket. Logs to events.

**For each: include input validation, auth check, event logging, error handling.**

---

## 🥧 7. RASPBERRY PI CONTROLLER

### Hardware (MVP)
- Raspberry Pi 4 (4GB+) or Pi 5
- Sonoff Zigbee 3.0 USB Dongle Plus (CC2652)
- MicroSD 64GB
- Power supply (official 5V/3A)
- Optional: Broadlink RM4 Mini (IR for AC)

### Software Stack
- Raspberry Pi OS Lite 64-bit (bookworm)
- Python 3.11+
- Mosquitto MQTT broker
- Zigbee2MQTT (Docker)
- systemd service for `qlvin-pi`

### File: `pi/setup.sh` (one-line installer)

```bash
#!/usr/bin/env bash
# QLVIN OS — Raspberry Pi Setup Script
# Run: curl -sSL https://raw.githubusercontent.com/qlvin/qlvin-os/main/pi/setup.sh | sudo bash

set -e
echo "🥧 Qlvin Pi Setup starting..."

# 1. System packages
apt update && apt upgrade -y
apt install -y python3-pip python3-venv mosquitto mosquitto-clients git docker.io docker-compose

# 2. Mosquitto config (local-only)
cat > /etc/mosquitto/conf.d/qlvin.conf <<EOF
listener 1883
allow_anonymous true
EOF
systemctl enable mosquitto
systemctl restart mosquitto

# 3. Zigbee2MQTT (Docker)
mkdir -p /opt/zigbee2mqtt/data
docker run -d \
  --name=zigbee2mqtt \
  --restart=always \
  -v /opt/zigbee2mqtt/data:/app/data \
  --device=/dev/ttyUSB0 \
  -p 8080:8080 \
  -e TZ=Asia/Riyadh \
  koenkk/zigbee2mqtt:latest

# 4. Clone Qlvin Pi
cd /opt
git clone https://github.com/qlvin/qlvin-os.git
cd qlvin-os/pi
python3 -m venv venv
./venv/bin/pip install -r requirements.txt

# 5. Config from env
cp config.example.yaml config.yaml
echo "✏️  Edit /opt/qlvin-os/pi/config.yaml with your unit_id and Supabase credentials"

# 6. systemd
cp qlvin.service /etc/systemd/system/
systemctl enable qlvin
echo "✅ Setup complete. Edit config.yaml then: sudo systemctl start qlvin"
```

### File: `pi/main.py`

```python
"""
QLVIN OS — Raspberry Pi Controller
Subscribes to MQTT, controls Zigbee devices, syncs state to Supabase.
"""
import asyncio
import logging
import yaml
from services.mqtt_service import MQTTService
from services.supabase_service import SupabaseService
from services.heartbeat_service import HeartbeatService
from services.automation_service import AutomationService

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
log = logging.getLogger("qlvin")

async def main():
    # Load config
    with open("config.yaml") as f:
        config = yaml.safe_load(f)
    
    log.info(f"🚀 Starting Qlvin Pi for unit {config['unit_id']}")
    
    # Initialize services
    supabase = SupabaseService(config)
    mqtt = MQTTService(config)
    heartbeat = HeartbeatService(config, supabase)
    automation = AutomationService(config, supabase, mqtt)
    
    # Start all services concurrently
    await asyncio.gather(
        mqtt.connect_and_listen(),
        heartbeat.run(),
        automation.listen()
    )

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("👋 Shutting down")
```

### MQTT Topics

```
qlvin/{unit_id}/device/{device_id}/set      # Cloud → Pi (command)
qlvin/{unit_id}/device/{device_id}/state    # Pi → Cloud (state update)
qlvin/{unit_id}/events                      # Pi → Cloud (events)
qlvin/{unit_id}/scene/set                   # Cloud → Pi (scene activation)
qlvin/{unit_id}/presence                    # Pi → Cloud (presence event)
qlvin/{unit_id}/heartbeat                   # Pi → Cloud (every 30s)
```

---

## 🎨 8. THE FEATURE BUILDER UI (in host_v6.html)

**Critical:** This is the host's "tablet builder". Add it as a new section/modal in the existing `host_v6.html` without breaking the design.

### Behavior:
1. Host clicks on a unit → opens unit detail
2. There's a button "🏗️ بناء التابلت"
3. Modal opens showing all features from `feature-registry.json`
4. Each feature has:
   - Toggle (ON/OFF)
   - Settings button (⚙️) → opens config panel
   - Lock icon if founder disallowed
5. Bottom: [معاينة] [حفظ]
6. On save: UPDATE `units.features` JSONB → Realtime sync → tablet rebuilds instantly

### Code structure:
```javascript
// apps/host/src/tablet-builder.js
class TabletBuilder {
  constructor(unitId) { this.unitId = unitId; }
  async load() {
    this.registry = await fetch('/packages/qlvn-config/feature-registry.json').then(r => r.json());
    this.unit = await supabase.from('units').select('*').eq('id', this.unitId).single();
    this.platformDefaults = await supabase.from('platform_feature_defaults').select('*');
  }
  render() { /* build modal HTML */ }
  toggleFeature(key) { /* update local state */ }
  async save() {
    await supabase.from('units').update({ features: this.unit.features }).eq('id', this.unitId);
    showNotif('💾', 'تم حفظ التعديلات');
  }
}
```

---

## 🪞 9. REALTIME SYNC ARCHITECTURE

Every UI subscribes to its relevant channel:

```javascript
// Tablet
supabase.channel(`unit:${UNIT_ID}`)
  .on('postgres_changes', { event: '*', schema: 'public', table: 'units', filter: `id=eq.${UNIT_ID}` },
      payload => rebuildTabletUI(payload.new))
  .subscribe();

// Mobile Guest Card
supabase.channel(`session:${SESSION_ID}`)
  .on('postgres_changes', { event: '*', schema: 'public', table: 'guest_sessions', filter: `id=eq.${SESSION_ID}` },
      payload => updateCardState(payload.new))
  .subscribe();

// Host Dashboard
supabase.channel(`host:${HOST_ID}`)
  .on('postgres_changes', { event: '*', schema: 'public', table: 'events', filter: `host_id=eq.${HOST_ID}` },
      payload => addToActivityFeed(payload.new))
  .subscribe();

// Founder Dashboard
supabase.channel(`founder`)
  .on('postgres_changes', { event: '*', schema: 'public', table: 'units' }, refreshUnitsList)
  .on('postgres_changes', { event: '*', schema: 'public', table: 'events' }, addLiveEvent)
  .subscribe();
```

---

## 🚀 10. STEP-BY-STEP EXECUTION ORDER

Execute these in this exact order. Do not skip steps.

### Step 1: Init Repository (15 min)
- `mkdir qlvin-os && cd qlvin-os`
- Create folder structure from §3
- Init git, npm/pnpm workspaces
- Add `.env.example`, `.gitignore`, basic `README.md`

### Step 2: Place Approved HTML Files (5 min)
- Copy `founder_v4_final.html` → `apps/founder/index.html` (no edits)
- Copy `host_v6.html` → `apps/host/index.html` (no edits)
- Copy `guest_smart_card_v3.html` → `apps/guest-card/index.html` (no edits)
- Copy `guest_tablet_v1.html` → `apps/tablet/index.html` (no edits)

### Step 3: Supabase Setup (1 hour)
- Create project at supabase.com
- Run `supabase init` locally
- Add migrations from §4
- Add seed data (1 founder, 1 host, 1 demo unit)
- `supabase db push`

### Step 4: Feature Registry (30 min)
- Create `packages/qlvn-config/`
- Add `feature-registry.json` and `default-config.json` from §5
- Create simple validator function

### Step 5: Edge Functions (4 hours)
- Implement all 8 functions from §6
- Test each with `supabase functions serve`
- Deploy with `supabase functions deploy`
- Set secrets

### Step 6: Frontend Integration (1 day)
For each HTML file:
- Add `<script src="src/supabase-client.js">` at bottom
- **DO NOT MODIFY any visual code**
- Replace hardcoded mock data with Supabase queries
- Add Realtime subscriptions
- Wire every button to an action

### Step 7: Founder Approval Workflow (4 hours)
- Founder sees pending units (red badge)
- Click → modal with details
- Approve / Reject / Suspend buttons
- Reject requires reason
- Notify host on each action

### Step 8: Host Unit Creation (4 hours)
- "+ Add unit" button in host_v6
- Modal with form (name, location, WiFi, iCal URLs, prices)
- Submit → INSERT with `approval_status='pending_approval'`
- Show "في انتظار الموافقة" badge

### Step 9: Tablet Builder UI (1 day)
- New section in `host_v6` for selected unit
- Read `feature-registry.json`
- Render toggles + settings
- Save updates `unit.features` JSONB
- Realtime push to tablet

### Step 10: Dynamic Tablet (1 day)
- `apps/tablet/src/feature-renderer.js`
- On load: validate token → fetch `unit.features` → build UI
- On Realtime update: rebuild UI smoothly
- Each feature: render only if `enabled: true`

### Step 11: Guest Card Generator (4 hours)
- iCal sync creates booking
- Trigger creates guest_session + token
- Edge Function sends WhatsApp with `https://qlvin.app/g/{token}`
- Card validates token on load

### Step 12: Nawaf Engine (1 day)
- 80% scripted responses (JSON dictionary)
- 20% Gemini fallback via Edge Function
- Trigger on Netflix confusion
- Match day suggestions

### Step 13: Raspberry Pi (1 day)
- Write `pi/main.py` and services
- Test MQTT round-trip
- Implement AC + Light controllers
- Heartbeat to Supabase

### Step 14: End-to-End Testing (1 day)
- Founder approves unit
- Host adds unit via dashboard
- iCal pulls test booking
- Guest receives WhatsApp
- Opens card, controls work
- Tablet syncs with card
- Pi receives MQTT commands
- All events logged

### Step 15: Deployment (4 hours)
- Netlify for each app (4 sites)
- Supabase Edge Functions deployed
- GitHub Actions CI/CD
- Custom domain qlvin.app

### Step 16: Documentation (2 hours)
- README with quickstart
- Architecture diagram
- Pi setup guide
- Add new feature guide

---

## ✅ 11. DEFINITION OF DONE

The MVP is complete when this checklist passes:

- [ ] Repo on GitHub with clean commit history
- [ ] All 4 apps deployed to Netlify
- [ ] Supabase backend live with seed data
- [ ] All 8 Edge Functions working
- [ ] **Founder can:** add host, approve/reject units, see live events, kill switch any unit
- [ ] **Host can:** log in, add unit (goes pending), see approval status, build tablet config, see bookings, send guest card
- [ ] **Guest card:** opens with valid token, expires at checkout, all enabled buttons work, syncs with tablet
- [ ] **Tablet:** loads unit features dynamically, all enabled features work, Nawaf appears on Netflix confusion, syncs with mobile card
- [ ] **Pi:** boots → heartbeats Supabase → receives MQTT commands → controls one real device
- [ ] **End-to-end test:** booking from iCal → guest WhatsApp → card opened → AC adjusted via voice → all events logged
- [ ] Demo video recorded

---

## 🌍 12. ENV VARIABLES

```bash
# .env.example
# Supabase
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_ANON_KEY=eyJxxx
SUPABASE_SERVICE_ROLE_KEY=eyJxxx

# Gemini
GEMINI_API_KEY=AIxxx

# Twilio (or mock for MVP)
TWILIO_ACCOUNT_SID=ACxxx
TWILIO_AUTH_TOKEN=xxx
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886

# MQTT (Pi side)
MQTT_BROKER_URL=mqtt://broker.qlvin.app:1883
MQTT_USERNAME=qlvin
MQTT_PASSWORD=xxx

# App
APP_URL=https://qlvin.app
APP_NAME=Qlvin OS
```

---

## 💎 13. ADDING A NEW FEATURE LATER (the magic)

To add a new feature (e.g., "Order Sushi"):

1. Add to `feature-registry.json`:
```json
{
  "key": "order_sushi",
  "category": "ordering",
  "label_ar": "طلب سوشي",
  "icon": "🍣",
  "default_enabled": false,
  "config_schema": { "menu": { "type": "array_of_objects" } }
}
```

2. Add renderer in `apps/tablet/src/feature-renderer.js`:
```javascript
features.order_sushi && renderOrderSushiCard(config.order_sushi.config);
```

3. Done. The Builder UI auto-shows the new feature. Hosts can enable it per unit. Tablet renders it. No code changes needed elsewhere.

---

## 🆘 14. WHEN STUCK

- **UI doesn't update:** Check Realtime subscription is active
- **Token invalid:** Check `token_expires_at` and `status='active'`
- **Gemini returns bad JSON:** Use schema validator; fallback to 'unknown' intent
- **Pi can't reach broker:** Check MQTT credentials and firewall
- **Host can't approve:** They shouldn't — only founders approve
- **Feature missing on tablet:** Check `unit.features.{key}.enabled === true`

---

## 📞 15. CONTACTS

- **Founder:** Sulaiman Al-Qahtani — Saudi Arabia
- **Partner:** Abdulkader
- **Repo:** github.com/qlvin/qlvin-os
- **Domain:** qlvin.app

---

## 📜 LICENSE

Proprietary. © 2026 Qlvin OS. All rights reserved.

---

# 🎯 START NOW

If you've read everything above, begin with **Step 1** in §10. Do not improvise. Do not skip. Do not redesign HTML.

**The standard:** Every button works. Every feature toggleable. Every event logged. Every connection live.

This is not a prototype. This is the foundation of a real business.

**Go.**
